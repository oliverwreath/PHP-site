		
<?php include_once("header.php");
		include_once("head.php")?>
		
	</head>

	<body>
		<?php include_once("navigation.php") ?>
		<div id="fb-root"></div>
		<script>(function(d, s, id) {
		  var js, fjs = d.getElementsByTagName(s)[0];
		  if (d.getElementById(id)) return;
		  js = d.createElement(s); js.id = id;
		  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
		  fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));</script>

		<?php include_once("./analytic/analyticstracking.php") ?>


		<div class="center">
			<table>
				<tr>
					<td>
						<br/>
						<h2>Yanliang H.</h2>
						<h3>Masters Candidate of CS in</h3>
						<h3>University of Illinois at Urbana-Champaign</h3>
						<h3>ACM and IEEE S. Member</h3>
						<hr/>
						<h3>Works Gallery - To be continued.</h3>
						<table style="width:100%">
							<tr style="width:100%">
								<td style="width:250px">
									<iframe src="http://free.timeanddate.com/clock/i3ve6qlp/n137/szw110/szh110/hocfff/hbw0/hfc222/cf100/hnc000/fav0/fiv0/mqc0f0/mqs2/mql4/mqw4/mqd86/mhc0f0/mhs2/mhl4/mhw4/mhd86/mmc0f0/mml2/mmd88/hhc00f/hhs3/hhl50/hhw11/hmc00f/hms3/hml80/hmw11/hsc00f/hsl90/hsw6" frameborder="0" width="112" height="112"></iframe>
								</td>
								<td style="width:250px">
									
								</td>
							</tr>
						</table>
						<h3>Research Interests: Compilers, Object-Oriented Programming, Machine Learning, Computer Vision, Data Mining, Algorithms, Information Security and bringing improvements to people's life with cutting-edge technologies.</h3> 
					</td>
				</tr>
				
				<?php include_once("bottom.php") ?>
				
			</table>
		</div>
	</body>
</html>