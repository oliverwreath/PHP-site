<?php
$user="fourgrad_db";
$db="fourgrad_db";
$pass="7mkTn2x-gGyv";
$server="localhost";
?>