
		<div class="download_bar">
			<div id="download-container">
				
				<script type="text/javascript">var switchTo5x=true;</script>
				<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
				<script type="text/javascript">stLight.options({publisher: "dbaf76be-e7be-4a9f-8e6c-f48a88f601ff", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>
				
				<span class='st_sharethis_large'></span>
				<span class='st_facebook_large'></span>
				<span class='st_twitter_large'></span>
				<span class='st_linkedin_large'></span>
				<span class='st_pinterest_large'></span>
				<span class='st_googleplus_large'></span>
				<span class='st_reddit_large'></span>
				<span class='st_tumblr_large'></span>
				<span class='st_email_large'></span>
				<p>
				<a href="http://jigsaw.w3.org/css-validator/check/referer">
				    <img style="border:0;width:88px;height:31px"
				        src="http://jigsaw.w3.org/css-validator/images/vcss-blue"
				        alt="Valid CSS!" />
				</a>
				</p>
				<hr/>
				<p style="font-size: 10pt">© 2014 Yanliang H.</p>
			</div>
		</div>