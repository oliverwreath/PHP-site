		<ul id="menu">
			<li><a href = "/">Home</a></li>
			<li><a href = "/docs/Resume.pdf" target="_blank">► Full Resume</a></li>
			<li><a href = "http://www.linkedin.com/in/yanliangoliver" target="_blank">LinkedIn</a></li>
			<li><a href = "http://github.com/oliverwreath" target="_blank">GitHub</a></li>
			<li>|</li>
			<li><a href = "research.php">Academic</a></li>
			<li><a href = "projects.php">Projects</a></li>
			<li>|</li>
			<li><a href = "light.php">JavaScript Lab</a></li>
			<li>|</li>
			<li style ="width:100%"></li>	
		</ul> 