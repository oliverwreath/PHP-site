<?php
include('header.php');
include('common.php');
logout();
?>