<?php
$user="skywalk6_db";
$db="skywalk6_db";
$pass="()+HYLhyl771";
$server="localhost";
?>