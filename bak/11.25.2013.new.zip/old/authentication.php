<?php
$user="skywalk6_db";
$db="skywalk6_Database_Admin";
$pass="()+HYLhyl771";
$server="localhost";
?>