<?php include_once("header.php")  ?>

<body>
	<style>
	@import url(http://fonts.googleapis.com/css?family=Open+Sans:400,600);
	</style>
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
	</script>
	<script type="text/javascript">
	_uacct = "UA-3125611-1";
	urchinTracker();
	</script>

	<div style="position: relative; width: 100%">
	<center>
	
		<?php include_once("navi.php") ?>

		<div style="width: 960px">
			<h1><span class="title1">Yanliang</span> H.</h1>
			<p style="font-size: 16px; width: 650px; margin-top: 0px">Master of Computer Science in University of Illinois at Urbana-Champaign</p>
			<p>ACM, IEEE Member</p>
		</div>

		<div class="band">
			<table>
				<tr>
					<td>
						<h3>Works Gallery - To be continued.</h3>
						<table style="width:100%">
							<tr style="width:100%">
								<td style="width:250px">
									<h3>Panorama Stitching</h3>
									<div>
										<a href="/pics/Capture33.jpg"  target="_blank">
											<img style="width:100%" src="http://www.skywalkerhunter.com/pictures/Capture33.jpg" alt="Panorama Stitching! Yee, Haw!" />
										</a>
										<a href="/pics/Capture32.jpg"  target="_blank">
											<img style="width:100%" src="http://www.skywalkerhunter.com/pictures/Capture32.jpg" alt="Panorama Stitching! Yee, Haw!" />
										</a>
									</div>
								</td>
								<td style="width:250px">
									<h3>Full featured Tutor Search</h3>
									<h3>With Live Demo!</h3>
									<div>
										<a href="http://fourgrad.yanliangh.org"  target="_blank">
											<img style="width:100%" src="/pics/ITS.png" alt="ITS" />
										</a>
										<a href="http://youtu.be/0LILG0sJjjM"  target="_blank">
											<img style="width:100%" src="/pics/Video.png" alt="ITS" />
										</a>
									</div>
								</td>
							</tr>
						</table>
						<h3>Research Interests: Compilers, Object-Oriented Programming, Machine Learning, Computer Vision, Data Mining, Algorithms, Information Security and bringing improvements to people's life with cutting-edge technologies.</h3> 
					</td>
				</tr>
			</table>
		</div>

		<?php include_once("footer.php") ?>

	</center>
	</div>

</body>
</html>