		<center>
		<div class="download_bar">
			<div id="download-container">
				<table>
					<tr>
						<td>
							<script type="text/javascript">var switchTo5x=true;</script>
							<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
							<script type="text/javascript">stLight.options({publisher: "dbaf76be-e7be-4a9f-8e6c-f48a88f601ff", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>
							
							<span class='st_sharethis_large' displayText='ShareThis'></span>
							<span class='st_facebook_large' displayText='Facebook'></span>
							<span class='st_twitter_large' displayText='Tweet'></span>
							<span class='st_linkedin_large' displayText='LinkedIn'></span>
							<span class='st_pinterest_large' displayText='Pinterest'></span>
							<span class='st_googleplus_large' displayText='Google +'></span>
							<span class='st_reddit_large' displayText='Reddit'></span>
							<span class='st_tumblr_large' displayText='Tumblr'></span>
							<span class='st_email_large' displayText='Email'></span>
						</td>
					</tr>
				</table>
				<hr/>
				<p style="font-size: 10pt">© 2014 Yanliang H.</p>
			</div>
		</div>
		</center>