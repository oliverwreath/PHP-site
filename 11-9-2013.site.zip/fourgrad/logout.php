<?php
include('header.php');
include('common.php');
logout();
?>
<meta http-equiv="refresh" content="0;url=http://www.skywalkerhunter.com/fourgrad/index.php" /> 