<div id="navigate_ID" class="navigate_class">
	<div class="navigate_sub">
		<ul id="sc_hdu" class="sc_hl1">
			<li class="" style=""><a href = "/">Home</a></li>
			<!--<li id="scpt1" class="" ><a href = "greetings.php">Greetings</a></li>-->
			<li class="" ><a href = "https://www.skywalkerhunter.com/Resume.pdf" target="_blank">Resume</a></li>
			<li class="" ><a href = "http://www.linkedin.com/in/yanliangoliver" target="_blank">LinkedIn</a></li>
			<li class="" ><a href = "https://github.com/oliverwreath" target="_blank">GitHub</a></li>
			<!--<li class="" ><a href = "research.php">Academic Experience</a></li>-->
			<!--<li class="" ><a href = "projects.php">Practical Experience</a></li>-->
			<li class="grey_seperator">|</li>
			<li id="scpt5" class="" ><a href = "resources.php" target="_blank">Resources</a></li>
			<li class="" style=""><a href = "timer.php">Timer</a></li>
			<li class="grey_seperator">|</li>
			<!--<li id="" class=""><a href = "Admin_Portal.php" target="_blank">Admin Portal</a><li>-->
			<li style ="width:100%"></li>	
		</ul>
	</div>
</div>